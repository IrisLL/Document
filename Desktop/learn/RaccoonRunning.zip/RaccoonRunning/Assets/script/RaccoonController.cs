﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RaccoonController : MonoBehaviour {

	Animator anim;
	bool jump=false;
	bool run=false;
	bool slide=false;
	bool hit=false;
	bool death=false;
	public bool start=true;
	int starcount=0;
	public GameObject score;
	public GameObject final;

	public float Vspeed;
	public float Hspeed;
	public float maxspeed;
	public float minspeed;
	public float jumpheight=10.0f;

	//public Transform cameraTransform;
	public GameManager gameManager;

	public GameObject win;
	public AudioSource jumpsound;
	public AudioSource coinsound;

	// Use this for initialization
	void Start () {
		

		anim = GetComponent<Animator> ();
		anim.SetBool ("jump",jump);
		anim.SetBool ("run",run);
		anim.SetBool ("slide",slide);
		anim.SetBool ("hit",hit);
		anim.SetBool ("death",death);	
		anim.SetBool ("start",start);
		win.SetActive (false);
		score.GetComponent<Text> ().text = "0";
		final.GetComponent<Text> ().text = "0";

	}

	// Update is called once per frame
	 void Update () {
		if (!start) {
			score.GetComponent<Text> ().text = starcount.ToString ();
			final.GetComponent<Text> ().text = starcount.ToString ();
			anim.SetBool ("start", start); 
			if (Input.GetKeyDown ("1"))
				anim.Play ("Cat_HappyDance", -1, 0);

			if (Input.GetKey (KeyCode.Space)) {
				jump = true;
				jumpsound.Play ();
				GetComponent<Rigidbody>().velocity+=new Vector3(0,jumpheight,0);
			} else
				jump = false;
			anim.SetBool ("jump", jump); 

			if (Input.GetKey (KeyCode.LeftShift)) {
				slide = true;
			} else
				slide = false;
			anim.SetBool ("slide", slide); 


			float inputH = Input.GetAxis ("Horizontal");
			float inputV = Input.GetAxis ("Vertical");

			anim.SetFloat ("inputH", inputH);
			anim.SetFloat ("inputV", inputV);

			/*float movex = inputH * 5 * Time.deltaTime;
		float movez = inputV * 20 * Time.deltaTime;*/
			if((Input.GetKey (KeyCode.LeftAlt))||(Input.GetKey (KeyCode.RightAlt))) {
				run = true;
			} else
				run = false;
			anim.SetBool ("run", run);
		 

			/*if (Input.GetKey (KeyCode.S)) {
			hit = true;

			//hitcount++;
			//Debug.Log (hitcount);
		} else
			hit = false;
		anim.SetBool ("hit", hit);*/


			if (hit == true) {
				death = true;
			}
			anim.SetBool ("death", death);

			if (death == true) {
				win.SetActive (true);
			}


			if (run) {
				if (Vspeed < maxspeed && Hspeed < minspeed) {
					Vspeed *= 1.5f;
					Hspeed *= 1.5f;
				}
			} 

			//transform.Translate (movex, 0, movez);
			Vector3 vSpeed = new Vector3 (this.transform.forward.x, this.transform.forward.y, this.transform.forward.z) * Vspeed;
			Vector3 hSpeed = new Vector3 (this.transform.right.x, this.transform.right.y, this.transform.right.z) * Hspeed * inputH;
		
			if (!death)
				transform.position += (vSpeed + hSpeed) * Time.deltaTime;
		}
	}
	void OnTriggerEnter(Collider other) {

		// 如果是抵达点
		if (other.name.Equals ("arrive")) {
			Debug.Log ("arrive collider");	
			gameManager.changeRoad (other.transform);
		}
		// 如果是透明墙
		else if (other.tag.Equals ("AlphaWall")) {
			// 没啥事情
			Debug.Log ("wall");
			hit = true;
			anim.SetBool ("hit", hit);
		}
		// 如果是障碍物
		else if (other.tag.Equals ("Obstacle")) {

			hit = true;
			Debug.Log ("obstacle" + hit);
			anim.SetBool ("hit", hit);

		} 
		else if (other.tag.Equals ("star")) {
			starcount++;
			coinsound.Play ();
			Debug.Log ("star"+starcount.ToString ());
		}
	}



}
