﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class levelwindow : MonoBehaviour {

	//Animator anim;
	public GameObject win;
	//bool isMoveIn=false;

	// Use this for initialization
	void Start () {
		
	}

	public void StartClick(){
		win.SetActive (true) ;
	}

	public void CloseClick(){
		win.SetActive (false) ;
	}

	// Update is called once per frame
	void Update () {

	}

	public void LevelOneClick(){
		SceneManager.LoadScene (1);
	}

	public void LevelTwoClick(){
		SceneManager.LoadScene (2);
	}
}
