﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour {

	public string characterName;
	public Animator animator;
	public bool runstate=false;
	// Use this for initialization
	public RaccoonController rcontrol;





}
