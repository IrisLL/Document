﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
public class TimeTimer : MonoBehaviour {
    float timer = 4;
	public GameObject t;
	public Character obj;
	public RaccoonController Rcontrol;

	public AudioSource countdown;

	// Use this for initialization
	void Start()
	{
		
		Rcontrol.start = true;
	}
	// Update is called once per frame
	void Update()
	{
		if (timer > 1) {
			int settime = (int)timer;
			t.GetComponent<Text> ().text = settime.ToString ();
			timer -= Time.deltaTime;
				countdown.Play ();
		} 
		else
		{
			//obj.RunState ();
			Rcontrol.start=false;
			//Debug.Log ("finish");
			countdown.Play ();
			Destroy (t);

		}
			
	}



}