﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaySound : MonoBehaviour {

	static PlaySound instance=null;
	static bool isPlay=true;
	public AudioSource bgm;

	// Use this for initialization
	void Start () {

	}

	public static PlaySound Instance
	{
		get { 
			return instance; 
		}
	}
	void Awake()
	{
		if (instance != null && instance != this) {
			Destroy(this.gameObject);
			return;
		} 
		else {
			instance = this;
		}
		DontDestroyOnLoad(this.gameObject);//使对象目标在加载新场景时不被自动销毁。
	}

	public void mute(){
		if (isPlay) {
			bgm.Pause ();
			isPlay = false;
			Debug.Log ("mute");
		} else {
			bgm.Play ();
			isPlay = true;
		}
			
	}

	// Update is called once per frame
	void Update () {

	}

}
