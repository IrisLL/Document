﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class changeimage : MonoBehaviour 
{
	public GameObject btnObj ;
	public Sprite  mute;
	public Sprite  unmute;
	Button btn;
	bool ismute=false ;
	// 初始化
	void Start () {
		btn = btnObj.GetComponent<Button>();
		btn.onClick.AddListener(delegate ()
			{
				ismute=!ismute;
				if (ismute)
				{
					//改变按钮图标
					btn.GetComponent<Image>().sprite=mute ;
				}
				else {
					btn.GetComponent<Image>().sprite=unmute;
				}
			});
	}

	// Update is called once per frame
	void Update () {

	}

}